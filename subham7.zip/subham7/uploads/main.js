const slides = [
  {
    name: "Shubham<br />Sharma",
    published: "Published By SS",
    label: "Power",
    body: "Complete Unpredictability, Chaos Agent, Customized Weapons, Wields Toxin Which Causes Victims To Die Laughing",
    tagA: "Intelligence",
    tagB: "Complete<br />Unpredictability",
  },
  {
    name: "Shubham<br />Sharma",
    published: "Published By SS",
    label: "Origin",
    body: "No single beginning is true. A failed comic, a chemical bath, one very bad day in Gotham — the story changes because he prefers it that way.",
    tagA: "Unknown Identity",
    tagB: "Gotham City",
  },
  {
    name: "Shubham<br />Sharma",
    published: "Published By SS",
    label: "Alias",
    body: "Clown Prince of Crime. Harlequin of Hate. Ace of Knaves. Red Hood. Each name is a costume; the laugh underneath never changes.",
    tagA: "Criminal Genius",
    tagB: "Chaos Agent",
  },
  {
    name: "Shubham<br />Sharma",
    published: "Published By SS",
    label: "Nemesis",
    body: "Batman is the other half of the joke. Order and anarchy, locked in a dance that neither man is willing — or able — to end.",
    tagA: "The Batman",
    tagB: "Arkham Asylum",
  },
  {
    name: "Shubham<br />Sharma",
    published: "Published By SS",
    label: "Legacy",
    body: "From Batman #1 in 1940 to cinema screens worldwide, he remains DC’s most unsettling idea: that a smile can be a weapon.",
    tagA: "Cultural Icon",
    tagB: "Since 1940",
  },
];

const posts = [
  {
    time: "04 Oct 2019",
    title: "A city that taught him to smile",
    img: "assets/blog-1.jpg",
    paragraphs: [
      "Gotham does not create monsters so much as it leaves the lights on for them. The rain never quite washes the streets. The neon never quite warms the rooms above them.",
      "In that weather a man can walk home from an empty club and decide the audience was wrong — that the joke was always on the city, and he had simply been telling it to the wrong room.",
      "This is not a review of a film. It is a note from the pavement: when a place stops looking at its people, someone will eventually make it look.",
    ],
  },
  {
    time: "12 Mar 1940",
    title: "Cards, roses, and a little vial",
    img: "assets/blog-2.jpg",
    paragraphs: [
      "The toxin arrives in the comics like a parlour trick and stays like a doctrine. Victims do not merely die. They are arranged — grinning, posed, turned into a punchline the city cannot look away from.",
      "Playing cards, a flower on the lapel, a glass vial no larger than a joke. The props are vaudeville. The chemistry is not.",
      "Eighty years on, the formula has changed on the page more than once. The idea has not: laughter, in the wrong hands, is a kind of violence.",
    ],
  },
  {
    time: "01 Apr 2024",
    title: "Behind the white paint",
    img: "assets/blog-3.jpg",
    paragraphs: [
      "Every version begins in a mirror. Greasepaint, a cracked bulb, a mouth drawn wider than the face can honestly hold.",
      "The dressing room is the most honest set in the myth. Before the crime, before the broadcast, there is only a man deciding how much of himself to cover — and how much to leave showing so the world will know it is a choice.",
      "The paint is not a disguise. It is a statement of terms. Meet me as the joke, or do not meet me at all.",
    ],
  },
];

const scaler = document.getElementById("scaler");
const stage = document.getElementById("stage");
const pagerDots = document.getElementById("pagerDots");
const charName = document.getElementById("charName");
const charPublished = document.getElementById("charPublished");
const statLabel = document.getElementById("statLabel");
const statBody = document.getElementById("statBody");
const tagAText = document.getElementById("tagAText");
const tagBText = document.getElementById("tagBText");
const homeCopy = document.querySelector(".home-copy");
const navLinks = document.querySelectorAll("[data-page]");
const pages = document.querySelectorAll(".page");

let index = 0;
let page = "home";
let locked = false;

function fit() {
  /* Fullscreen: the stage fills the viewport. No letterbox scale. */
}

function renderDots() {
  pagerDots.innerHTML = slides
    .map(
      (_, i) =>
        `<button class="pager-dot${i === index ? " is-current" : ""}" data-i="${i}" aria-label="Slide ${i + 1}"></button>`
    )
    .join("");
}

function applySlide(i) {
  const s = slides[i];
  homeCopy.classList.remove("is-swap");
  void homeCopy.offsetWidth;
  homeCopy.classList.add("is-swap");
  charName.innerHTML = s.name;
  charPublished.textContent = s.published;
  statLabel.textContent = s.label;
  statBody.textContent = s.body;
  tagAText.innerHTML = s.tagA;
  tagBText.innerHTML = s.tagB;
  index = i;
  renderDots();
}

function go(i) {
  if (locked || page !== "home") return;
  const next = (i + slides.length) % slides.length;
  if (next === index) return;
  locked = true;
  applySlide(next);
  setTimeout(() => {
    locked = false;
  }, 400);
}

function showPage(name) {
  if (name === "reader") {
    page = "reader";
  } else {
    page = name;
  }
  pages.forEach((p) => p.classList.toggle("is-active", p.dataset.view === name));
  document.querySelectorAll(".menu a").forEach((a) => {
    a.classList.toggle("is-active", a.dataset.page === (name === "reader" ? "blog" : name));
  });
  if (name !== "home" && location.hash !== `#${name}`) {
    history.replaceState(null, "", `#${name}`);
  }
  if (name === "home") history.replaceState(null, "", "#home");
}

function openPost(i) {
  const post = posts[i];
  document.getElementById("readerImg").src = post.img;
  document.getElementById("readerTime").textContent = post.time;
  document.getElementById("readerTitle").textContent = post.title;
  document.getElementById("readerBody").innerHTML = post.paragraphs
    .map((p) => `<p>${p}</p>`)
    .join("");
  showPage("reader");
}

function routeFromHash() {
  const h = (location.hash || "#home").slice(1);
  if (["home", "movie", "about", "blog"].includes(h)) showPage(h);
}

window.addEventListener("resize", fit);
window.addEventListener("hashchange", routeFromHash);

document.addEventListener("click", (e) => {
  const pageLink = e.target.closest("[data-page]");
  if (pageLink) {
    e.preventDefault();
    const target = pageLink.dataset.page;
    if (target === "reader") return;
    showPage(target);
    return;
  }
  const dot = e.target.closest(".pager-dot");
  if (dot) go(Number(dot.dataset.i));
});

document.getElementById("scrollHint").addEventListener("click", () => go(index + 1));
document.getElementById("readerBack").addEventListener("click", () => showPage("blog"));

document.querySelectorAll(".post").forEach((el) => {
  el.addEventListener("click", () => openPost(Number(el.dataset.post)));
});

window.addEventListener(
  "wheel",
  (e) => {
    if (page !== "home") return;
    if (Math.abs(e.deltaY) < 12) return;
    go(index + (e.deltaY > 0 ? 1 : -1));
  },
  { passive: true }
);

window.addEventListener("keydown", (e) => {
  if (page !== "home") return;
  if (e.key === "ArrowDown" || e.key === "ArrowRight") go(index + 1);
  if (e.key === "ArrowUp" || e.key === "ArrowLeft") go(index - 1);
});

fit();
renderDots();
routeFromHash();
requestAnimationFrame(() => stage.classList.add("is-ready"));
